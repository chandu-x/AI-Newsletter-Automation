# Setup Guide

Detailed step-by-step instructions to get the AI Newsletter System running.

## Table of Contents
- [Prerequisites](#prerequisites)
- [API Key Setup](#api-key-setup)
- [n8n Installation](#n8n-installation)
- [Workflow Import](#workflow-import)
- [Configuration](#configuration)
- [Testing](#testing)
- [Troubleshooting](#troubleshooting)

## Prerequisites

Before you begin, ensure you have:

1. **n8n Account/Installation**
   - Option A: [n8n Cloud](https://n8n.io/cloud) (easiest)
   - Option B: [Self-hosted n8n](https://docs.n8n.io/hosting/)

2. **Required API Keys**
   - Tavily API key
   - OpenRouter API key
   - Gmail account

## API Key Setup

### 1. Tavily API

1. Go to [https://tavily.com](https://tavily.com)
2. Sign up for an account
3. Navigate to API Keys section
4. Copy your API key
5. **Cost**: Free tier available

### 2. OpenRouter API

1. Go to [https://openrouter.ai](https://openrouter.ai)
2. Create an account
3. Add credits to your account (minimum $5 recommended)
4. Generate an API key from Settings
5. Copy the API key
6. **Cost**: Pay-per-use (~$0.01-0.05 per newsletter)

### 3. Gmail API

1. In n8n, go to Credentials → New
2. Select "Gmail OAuth2"
3. Follow the OAuth flow to connect your Gmail account
4. Grant necessary permissions

## n8n Installation

### Cloud Version (Recommended for Beginners)

1. Sign up at [n8n.cloud](https://n8n.io/cloud)
2. Create a new workspace
3. Skip to [Workflow Import](#workflow-import)

### Self-Hosted with Docker

```bash
# Pull the n8n image
docker pull n8nio/n8n

# Run n8n
docker run -it --rm \
  --name n8n \
  -p 5678:5678 \
  -v ~/.n8n:/home/node/.n8n \
  n8nio/n8n
```

Access n8n at `http://localhost:5678`

### Self-Hosted with npm

```bash
# Install n8n globally
npm install n8n -g

# Start n8n
n8n start
```

## Workflow Import

1. **Download the Workflow File**
   - Clone this repository or download `AI_Newsletter_System.json`

2. **Import into n8n**
   - Open your n8n instance
   - Click "Workflows" in the left sidebar
   - Click "Import from File"
   - Select `AI_Newsletter_System.json`
   - Click "Import"

3. **Verify Import**
   - You should see 14 nodes connected in the workflow
   - Check that no nodes show error indicators

## Configuration

### Step 1: Add Tavily Credentials

1. Click on the "Initial Research" node
2. In the "Credentials" dropdown, click "Create New Credential"
3. Name it "Tavily account"
4. Paste your Tavily API key
5. Click "Save"
6. Repeat for "Research Topics" node (select existing credential)

### Step 2: Add OpenRouter Credentials

1. Click on any "OpenRouter Chat Model" node
2. Create new credential
3. Name it "OpenRouter account"
4. Paste your OpenRouter API key
5. Click "Save"
6. Apply to all three OpenRouter nodes

### Step 3: Connect Gmail

1. Click on "Create a draft" node
2. In credentials, click "Create New Credential"
3. Follow the OAuth flow
4. Grant Gmail permissions
5. Verify connection successful

### Step 4: Configure Newsletter Topic

1. Click on "Initial Research" node
2. Find the `query` field
3. Change to your desired topic:
   ```
   Examples:
   - "AI adoption for small businesses"
   - "Latest developments in renewable energy"
   - "Cybersecurity trends for enterprises"
   - "Marketing automation best practices"
   ```

### Step 5: Set Email Recipient

1. Click on "Create a draft" node
2. Find "Send To" in options
3. Change to your email address
4. **Note**: This creates a draft, not a sent email

### Step 6: Configure Schedule

1. Click on "Schedule Trigger" node
2. Choose your frequency:
   - **Weekly** (default): Every Monday at 9 AM
   - **Daily**: Every day at specific time
   - **Monthly**: First day of month
3. Save changes

## Testing

### Manual Test Run

1. Click "Execute Workflow" button (top right)
2. Watch the execution flow through nodes
3. Check for any errors
4. Verify Gmail draft was created

### Expected Execution Time
- **Total Duration**: 2-4 minutes
- **Initial Research**: 5-10 seconds
- **Planning Agent**: 15-30 seconds
- **Section Writing**: 60-90 seconds (parallel)
- **Editor Agent**: 30-60 seconds
- **Gmail Draft**: 2-5 seconds

### Verification Checklist

- [ ] All nodes show green checkmarks
- [ ] No error messages in execution log
- [ ] Gmail draft appears in your drafts folder
- [ ] Draft contains formatted HTML content
- [ ] Citations include clickable URLs
- [ ] Subject line is generated

## Troubleshooting

### Common Issues

#### "Tavily API Error: Invalid Key"
**Solution**: 
- Verify API key is copied correctly
- Check Tavily account has available credits
- Ensure no extra spaces in credential

#### "OpenRouter API Error: Insufficient Credits"
**Solution**:
- Add credits to OpenRouter account
- Minimum $5 recommended for testing

#### "Gmail API Error: Unauthorized"
**Solution**:
- Reconnect Gmail OAuth credential
- Ensure Gmail API is enabled in Google Cloud Console
- Check OAuth consent screen settings

#### "Workflow Times Out"
**Solution**:
- Check internet connection
- Verify all API services are operational
- Try reducing `max_results` in Tavily nodes

#### "No Citations in Output"
**Solution**:
- Verify Tavily is returning `raw_content`
- Check "include_raw_content": true in Research Topics node
- Review Section Writer Agent system prompt

### Debug Mode

Enable execution logging:
1. Settings → Workflow Settings
2. Enable "Save Execution Progress"
3. Set "Error Workflow" if needed
4. Re-run workflow
5. Check detailed logs in Executions tab

## Performance Optimization

### Reduce API Costs
- Adjust `max_results` in Tavily nodes (3 → 2)
- Use GPT-4-mini instead of GPT-5 for all agents
- Increase schedule interval (weekly → bi-weekly)

### Improve Speed
- Enable parallel execution in n8n settings
- Use faster models (GPT-3.5-turbo)
- Reduce word count limit in Editor Agent

### Enhance Quality
- Increase `max_results` in research nodes
- Add more specific system prompts
- Enable longer context windows in OpenRouter

## Next Steps

Once setup is complete:

1. **Activate the Workflow**
   - Toggle switch to "Active"
   - Workflow will run on schedule

2. **Monitor Executions**
   - Check "Executions" tab regularly
   - Review generated drafts
   - Adjust prompts as needed

3. **Customize Further**
   - Modify agent prompts
   - Add more research sources
   - Create custom output formats

## Support

If you encounter issues:
1. Check n8n [documentation](https://docs.n8n.io)
2. Search n8n [community forum](https://community.n8n.io)
3. Open an issue in this GitHub repository

---

**Happy Automating! 🚀**
